import scipy.io as sio
from numpy import *
import keras
from keras.models import Model
from keras.layers import *
from keras.optimizers import *
from keras.constraints import *
from keras import backend as K
from keras import regularizers
from keras import initializers
#from keras.utils import multi_gpu_model
import h5py
import os
import numpy as np
from keras.applications.vgg16 import VGG16
import matplotlib.pyplot as plt
import os
import tensorflow as tf
import keras.backend as KTF
import cv2
import csv
from tensorflow.keras.layers import Conv2D, Lambda
from tensorflow.keras.optimizers import Adam






os.environ["CUDA_VISIBLE_DEVICES"] = "0"
config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth=True
sess = tf.compat.v1.Session(config=config)
KTF.set_session(sess)

nb_filter = 64
nb_layers = [6, 12, 32, 32]  # For DenseNet-169



img1=cv2.imread('E:\\backProject_Markus\\0412\\808\\1.bmp',cv2.IMREAD_GRAYSCALE)
img2=cv2.imread('E:\\backProject_Markus\\0412\\808\\2.bmp',cv2.IMREAD_GRAYSCALE)
img3=cv2.imread('E:\\backProject_Markus\\0412\\808\\3.bmp',cv2.IMREAD_GRAYSCALE)
img4=cv2.imread('E:\\backProject_Markus\\0412\\808\\4.bmp',cv2.IMREAD_GRAYSCALE)
img5=cv2.imread('E:\\backProject_Markus\\0412\\808\\4.bmp',cv2.IMREAD_GRAYSCALE)
img6=cv2.imread('E:\\backProject_Markus\\0412\\808\\6.bmp',cv2.IMREAD_GRAYSCALE)
img7=cv2.imread('E:\\backProject_Markus\\0412\\808\\7.bmp',cv2.IMREAD_GRAYSCALE)
img8=cv2.imread('E:\\backProject_Markus\\0412\\808\\8.bmp',cv2.IMREAD_GRAYSCALE)
img9=cv2.imread('E:\\backProject_Markus\\0412\\808\\9.bmp',cv2.IMREAD_GRAYSCALE)

img1 = cv2.resize(img1, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img2 = cv2.resize(img2, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img3 = cv2.resize(img3, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img4 = cv2.resize(img4, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img5 = cv2.resize(img5, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img6 = cv2.resize(img6, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img7 = cv2.resize(img7, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img8 = cv2.resize(img8, (1280, 1024), interpolation=cv2.INTER_NEAREST)
img9 = cv2.resize(img9, (1280, 1024), interpolation=cv2.INTER_NEAREST)

img1[0:1024,0:1280]=img1[0:1024,0:1280]
img2[1:1024,0:1280]=img2[0:1023,0:1280]
img3[1:1024,0:1279]=img3[0:1023,1:1280]
img4[0:1024,0:1279]=img4[0:1024,1:1280]
img5[0:1023,0:1279]=img5[1:1024,1:1280]
img6[0:1023,0:1280]=img6[1:1024,0:1280]
img7[0:1023,1:1280]=img7[1:1024,0:1279]
img8[0:1024,1:1280]=img8[0:1024,0:1279]
img9[1:1024,1:1280]=img9[0:1023,0:1279]

print(img1.shape)


img10 = cv2.imread('E:\\backProject_Markus\\0412\\808\\result.bmp',cv2.IMREAD_GRAYSCALE)



print(img10.shape)


img1=img1.astype(np.float32)
img2=img2.astype(np.float32)
img3=img3.astype(np.float32)
img4=img4.astype(np.float32)
img5=img5.astype(np.float32)
img6=img6.astype(np.float32)
img7=img7.astype(np.float32)
img8=img8.astype(np.float32)
img9=img9.astype(np.float32)
img10 =img10.astype(np.float32)

img1 = np.expand_dims(img1,-1)
img2 = np.expand_dims(img2,-1)
img3 = np.expand_dims(img3,-1)
img4 = np.expand_dims(img4,-1)
img5 = np.expand_dims(img5,-1)
img6 = np.expand_dims(img6,-1)
img7 = np.expand_dims(img7,-1)
img8 = np.expand_dims(img8,-1)
img9 = np.expand_dims(img9,-1)
img10 = np.expand_dims(img10,-1)

img1 = np.expand_dims(img1,0)
img2 = np.expand_dims(img2,0)
img3 = np.expand_dims(img3,0)
img4 = np.expand_dims(img4,0)
img5 = np.expand_dims(img5,0)
img6 = np.expand_dims(img6,0)
img7 = np.expand_dims(img7,0)
img8 = np.expand_dims(img8,0)
img9 = np.expand_dims(img9,0)
img10 = np.expand_dims(img10,0)



my_loss_weights = {'conv2d_11':1,'lambda_9':1,'lambda_10':1,'lambda_11':2,'lambda_12':2,
                   'lambda_13':0,'lambda_14':2,'lambda_15':2,'lambda_16':1,'lambda_17':2}


def gaussian_kernel(size, sigma):
    # 生成二维高斯分布的卷积核
    x = np.arange(-size // 2 + 1, size // 2 + 1, dtype=np.float32)
    y = x[:, np.newaxis]
    kernel = np.exp(-(x ** 2 + y ** 2) / (2 * sigma ** 2))
    kernel = kernel / kernel.sum()
    return kernel

class GaussianBlur2D(Conv2D):
    def __init__(self, size=5, sigma=0.01, **kwargs):
        kernel = gaussian_kernel(size, sigma)
        kernel = kernel[:, :, np.newaxis, np.newaxis]
        super(GaussianBlur2D, self).__init__(filters=1, kernel_size=(size, size),
                                              padding='same', data_format='channels_last',
                                              trainable=False, use_bias=False,
                                              kernel_initializer=tf.constant_initializer(kernel),
                                              **kwargs)

def slice(x, h1, h2, w1, w2):
    """ Define a tensor slice function
    """
    return x[:, h1:h2, w1:w2, :]

def my_downsampling(x,img_h,img_w,method=0):
  """0：双线性差值。1：最近邻居法。2：双三次插值法。3：面积插值法"""
  x = tf.image.resize(x,(img_h,img_w),method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
  return x

def my_upsampling(x,img_h,img_w,method=0):
  """0：双线性差值。1：最近邻居法。2：双三次插值法。3：面积插值法"""
  x = tf.image.resize(x, (img_h, img_w), method=tf.image.ResizeMethod.BICUBIC)
  return x





class double_pixel(object):


    def dxp(self):
        inpt1 = Input(shape=(1024, 1280, 1))
        inpt2 = Input(shape=(1024, 1280, 1))
        inpt3 = Input(shape=(1024, 1280, 1))
        inpt4 = Input(shape=(1024, 1280, 1))
        inpt5 = Input(shape=(1024, 1280, 1))
        inpt6 = Input(shape=(1024, 1280, 1))
        inpt7 = Input(shape=(1024, 1280, 1))
        inpt8 = Input(shape=(1024, 1280, 1))
        inpt9 = Input(shape=(1024, 1280, 1))



        c1 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt1)
        c2 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt2)
        c3 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt3)
        c4 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt4)
        c5 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt5)
        c6 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt6)
        c7 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt7)
        c8 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt8)
        c9 = Conv2D(8, (3, 3), strides=(1, 1), padding='same', kernel_initializer='he_normal')(inpt9)

        concat1 = concatenate([c1,c2,c3,c4,c5,c6,c7,c8,c9], axis=3)



        conv1 = Conv2D(32, (9, 9), strides=(1, 1), padding='same', kernel_initializer='he_normal')(concat1)
        conv2 = Convolution2D(16, 1, 1, kernel_initializer='he_normal')(conv1)
        conv15 = Conv2D(1, (5, 5), strides=(1, 1), padding='same')(conv2)



        print('uconv15',conv15.shape)


        slice_1 = Lambda(slice, arguments={'h1': 2, 'h2': 1022, 'w1': 2, 'w2': 1278})(conv15)
        slice_2 = Lambda(slice, arguments={'h1': 1, 'h2': 1021, 'w1': 2, 'w2': 1278})(conv15)
        slice_3 = Lambda(slice, arguments={'h1': 1, 'h2': 1021, 'w1': 1, 'w2': 1277})(conv15)
        slice_4 = Lambda(slice, arguments={'h1': 2, 'h2': 1022, 'w1': 1, 'w2': 1277})(conv15)
        slice_5 = Lambda(slice, arguments={'h1': 3, 'h2': 1023, 'w1': 1, 'w2': 1277})(conv15)
        slice_6 = Lambda(slice, arguments={'h1': 3, 'h2': 1023, 'w1': 2, 'w2': 1278})(conv15)
        slice_7 = Lambda(slice, arguments={'h1': 3, 'h2': 1023, 'w1': 3, 'w2': 1279})(conv15)
        slice_8 = Lambda(slice, arguments={'h1': 2, 'h2': 1022, 'w1': 3, 'w2': 1279})(conv15)
        slice_9 = Lambda(slice, arguments={'h1': 1, 'h2': 1021, 'w1': 3, 'w2': 1279})(conv15)

        '''slice_1=GaussianBlur2D()(slice_1)
        slice_2 = GaussianBlur2D()(slice_2)
        slice_3 = GaussianBlur2D()(slice_3)
        slice_4 = GaussianBlur2D()(slice_4)
        slice_5 = GaussianBlur2D()(slice_5)
        slice_6 = GaussianBlur2D()(slice_6)
        slice_7 = GaussianBlur2D()(slice_7)
        slice_8 = GaussianBlur2D()(slice_8)
        slice_9 = GaussianBlur2D()(slice_9)'''


        out1 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_1)
        out2 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_2)
        out3 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_3)
        out4 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_4)
        out5 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_5)
        out6 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_6)
        out7 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_7)
        out8 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_8)
        out9 = Lambda(my_downsampling, arguments={'img_w': 638, 'img_h': 510})(slice_9)


        model = Model([inpt1,inpt2,inpt3,inpt4,inpt5,inpt6,inpt7,inpt8,inpt9], [conv15,out1,out2,out3,out4,out5,out6,out7,out8,out9],)
        model.compile(loss='mse',optimizer='adam',loss_weights=my_loss_weights)
        # model.summary()
        return model
inpt1 = img1
inpt2 = img2
inpt3 = img3
inpt4 = img4
inpt5 = img5
inpt6 = img6
inpt7 = img7
inpt8 = img8
inpt9 = img9

out15 = img10[:, 0:1024, 0:1280, :]

out1 = img1[:, 2:1022, 2:1278, :]
out2 = img2[:, 1:1021, 2:1278, :]
out3 = img3[:, 1:1021, 1:1277, :]
out4 = img4[:, 2:1022, 1:1277, :]
out5 = img5[:, 3:1023, 1:1277, :]
out6 = img6[:, 3:1023, 2:1278, :]
out7 = img7[:, 3:1023, 3:1279, :]
out8 = img8[:, 2:1022, 3:1279, :]
out9 = img9[:, 1:1021, 3:1279, :]

out1 = np.reshape(out1, (1020, 1276))
out2 = np.reshape(out2, (1020, 1276))
out3 = np.reshape(out3, (1020, 1276))
out4 = np.reshape(out4, (1020, 1276))
out5 = np.reshape(out5, (1020, 1276))
out6 = np.reshape(out6, (1020, 1276))
out7 = np.reshape(out7, (1020, 1276))
out8 = np.reshape(out8, (1020, 1276))
out9 = np.reshape(out9, (1020, 1276))
#out15 = np.reshape(out15, (1024, 1280))

out1 = cv2.resize(out1, (638, 510), interpolation=cv2.INTER_NEAREST)
out2 = cv2.resize(out2, (638, 510), interpolation=cv2.INTER_NEAREST)
out3 = cv2.resize(out3, (638, 510), interpolation=cv2.INTER_NEAREST)
out4 = cv2.resize(out4, (638, 510), interpolation=cv2.INTER_NEAREST)
out5 = cv2.resize(out5, (638, 510), interpolation=cv2.INTER_NEAREST)
out6 = cv2.resize(out6, (638, 510), interpolation=cv2.INTER_NEAREST)
out7 = cv2.resize(out7, (638, 510), interpolation=cv2.INTER_NEAREST)
out8 = cv2.resize(out8, (638, 510), interpolation=cv2.INTER_NEAREST)
out9 = cv2.resize(out9, (638, 510), interpolation=cv2.INTER_NEAREST)
#out15 = cv2.resize(out15, (2560, 2048), interpolation=cv2.INTER_NEAREST)

out1 = np.expand_dims(out1, -1)
out2 = np.expand_dims(out2, -1)
out3 = np.expand_dims(out3, -1)
out4 = np.expand_dims(out4, -1)
out5 = np.expand_dims(out5, -1)
out6 = np.expand_dims(out6, -1)
out7 = np.expand_dims(out7, -1)
out8 = np.expand_dims(out8, -1)
out9 = np.expand_dims(out9, -1)
#out15= np.expand_dims(out15, -1)

out1 = np.expand_dims(out1, 0)
out2 = np.expand_dims(out2, 0)
out3 = np.expand_dims(out3, 0)
out4 = np.expand_dims(out4, 0)
out5 = np.expand_dims(out5, 0)
out6 = np.expand_dims(out6, 0)
out7 = np.expand_dims(out7, 0)
out8 = np.expand_dims(out8, 0)
out9 = np.expand_dims(out9, 0)
#out15 = np.expand_dims(out15, 0)

class DOUBLEPIX_MODEL(object):
    def __init__(self):

        self.dpxnet = double_pixel()
        self.dpx=self.dpxnet.dxp()


    def train(self, epochs=2000, batch_size=1, save_interval=0):
        min_loss=10000000000000
        loss1 = np.zeros((50000,1))

        for epoch in range(epochs):

            dpx_loss = self.dpx.train_on_batch([inpt1,inpt2,inpt3,inpt4,inpt5,inpt6,inpt7,inpt8,inpt9],[out15,out1,out2,out3,out4,out5,out6,out7,out8,out9])


            print(epoch, dpx_loss)
            loss1[epoch]=dpx_loss[0]
            #print(loss)
            sio.savemat('E:\\backProject_Markus\\0412\\808\\loss.mat', {'loss': loss1})

            if dpx_loss[0] < min_loss:
                min_loss = dpx_loss[0]
                if epoch % 100 == 0:

                    [I15,I1,I2,I3,I4,I5,I6,I7,I8,I9] = self.dpx.predict([inpt1,inpt2,inpt3,inpt4,inpt5,inpt6,inpt7,inpt8,inpt9])

                    II = np.reshape(I15,[1024,1280])
                    #inpt5=II

                    II = II/II.max()*255

                    II = II.astype(np.int32)
                    print(II)
                    cv2.imwrite('E:\\backProject_Markus\\0412\\808\\result1.bmp',II)
                    #sio.savemat('E:\\backProject_Markus\\0412\\808\\loss.mat', {'loss': loss})
                    #sio.savemat('/home/wst/Downloads/re/DL_dpx_result0321.mat', {'result': II})




if __name__ == '__main__':
    dpx = DOUBLEPIX_MODEL()
    dpx.train(epochs=1000000, batch_size=1, save_interval=500)






















